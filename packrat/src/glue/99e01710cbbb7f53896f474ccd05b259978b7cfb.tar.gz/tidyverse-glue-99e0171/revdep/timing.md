# Check times

|   |package         |version | check_time|
|:--|:---------------|:-------|----------:|
|3  |dplyr           |0.7.0   |      142.5|
|4  |shinycssloaders |0.2.0   |         37|
|1  |datadogr        |0.1.0   |       30.7|
|2  |dbplyr          |1.0.0   |        7.3|


