# ConR
ConR


# Install ConR

Install [R](https://cran.r-project.org/).
You may want to install the latest version from github by using the following code:

```
install.packages("devtools")
devtools::install_github("gdauby/ConR")
```


See the associated [vignette](https://cran.r-project.org/web/packages/ConR/vignettes/my-vignette.html) for a overview of the different functions.



