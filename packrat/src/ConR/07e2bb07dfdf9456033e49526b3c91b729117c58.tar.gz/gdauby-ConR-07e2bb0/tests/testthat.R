library(testthat)
library(ConR)

test_check("ConR")
