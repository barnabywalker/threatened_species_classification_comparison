##
##  r u n g e . R  Runge Function
##


runge <- function(x) {
    1 / (1 + (5*x)^2)
}