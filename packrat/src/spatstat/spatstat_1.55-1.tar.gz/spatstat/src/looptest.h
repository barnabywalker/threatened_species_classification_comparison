/* 
   looptest.h

   Utilities for looping

   $Revision: 1.1 $ $Date: 2014/09/19 00:47:34 $
*/
  
/* a small value relative to threshold X, for loop exit test */

#define EPSILON(X) ((X)/64)

